package com.automation.framework.browserProfile;

public abstract class BrowserProfile {
	public abstract Object createProfile();
}
